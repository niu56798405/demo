package com.hoolai.jdbc.test;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.hoolai.jdbc.Configuration;
import com.hoolai.jdbc.PSSetter;
import com.hoolai.jdbc.TypeQuery;
import com.hoolai.jdbc.datasource.DBConf;
import com.hoolai.jdbc.sequal.Sequal;

public class JDBCTest {
	
	public static enum TE {
		NONE;
	}

	public static void main(String[] args) {
	    DBConf conf = new DBConf("192.168.1.121", 3306, "test", "root", "sangoroot!@#");
	    Configuration.configureDatabase(TE.NONE, conf);
		TypeQuery<TA> query = new TypeQuery<TA>(TA.class)
				.binding(TE.NONE, "ta")
				.mapping("id", "Ident")
				.binding(0, "delete from ta where Ident = ?")
				.binding(1, "update ta set Name = ? where Ident = ?")
				.binding(2, Sequal.build().where("Ident").orderby("Ident").select())
//				.binding(2, "select a.* from ta a where Ident = ?")
				.binding(3, "select a.* from ta a where Ident <> ?")
				.binding(4, "insert into ta(`Ident`, `Name`, `EnumT`, `ArrayT`)values(?, ?, ?, ?)")
                .compile();
		
		TA ta = new TA(100, "nihao");
		
		System.out.println("insert ret : " + query.insert(ta));
		System.out.println("queryone by key ret : " + query.fetchoneByKey(100));
		
		ta.name = "sayHey";
		System.out.println("update by key ret : " + query.updateByKey(ta));
		System.out.println("delete by key ret : " + query.deleteByKey(100));
		System.out.println("select by sql : " + query.load(2).fetchOne(new PSSetter() {
			@Override
			public void set(PreparedStatement pstmt) throws SQLException {
				pstmt.setLong(1, 1000);
			}
		}));
		System.out.println("select by sql : " + query.load(3).fetchOne(pstmt->pstmt.setLong(1, 1000)));
		ta.name ="google";
		System.out.println("update by sql : " + query.load(1).update(ta));
		System.out.println("queryall ret : " + query.fetchall());
		ta.setId(1000);
		System.out.println("delete by sql : " + query.load(0).update(ta));
		System.out.println("insert by sql : " + query.load(4).update(ta));
		System.out.println("queryall ret : " + query.fetchall());
	}

}
