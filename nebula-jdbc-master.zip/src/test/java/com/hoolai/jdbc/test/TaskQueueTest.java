package com.hoolai.jdbc.test;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.hoolai.jdbc.sequal.SQLRunnable;
import com.hoolai.jdbc.sequal.SQLTask;
import com.hoolai.jdbc.sequal.SQLTaskQueue;

public class TaskQueueTest {
    
    static StringBuilder sb = new StringBuilder();
    static AtomicInteger ai = new AtomicInteger(100);
    
    static class A implements SQLRunnable {
        int x;
        long y = System.nanoTime();
        public A(int x) {
            this.x = x;
        }
        @Override
        public void exec() {
            sb.append(x).append('\t').append(y).append('\n');
        }
        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + x;
            return result;
        }
        @Override
        public boolean equals(Object obj) {
            if (this == obj)
                return true;
            if (obj == null)
                return false;
            if (getClass() != obj.getClass())
                return false;
            A other = (A) obj;
            if (x != other.x)
                return false;
            return true;
        }
    }
    
    public static void main(String[] args) throws InterruptedException {
        ExecutorService execs = Executors.newFixedThreadPool(10);
        ExecutorService execs1 = Executors.newFixedThreadPool(2);
        SQLTaskQueue queue = new SQLTaskQueue(execs1);
        for (int i = 0; i < 1; i++) {
            execs.execute(new Runnable() {
                @Override
                public void run() {
                    for (int j = 0; j < 3; j++) {
                        int get = ai.incrementAndGet();
                        new SQLTask(queue, new A(get)).checkin();
                        new SQLTask(queue, new A(get)).checkin();
                    }
                }
            });
        }
        for (int i = 0; i < 1; i++) {
            execs.execute(new Runnable() {
                @Override
                public void run() {
                    for (int j = 0; j < 2; j++) {
                        int get = ai.incrementAndGet();
                        new SQLTask(queue, new A(get)).checkin();
                        new SQLTask(queue, new A(get)).checkin();
                    }
                }
            });
        }
        execs.shutdown();
        TimeUnit.SECONDS.sleep(2);
        execs1.shutdown();
        System.err.println(queue.size());
        System.out.println(sb.toString());
    }

}
