package com.hoolai.jdbc.sequal;

import java.util.List;

import com.hoolai.jdbc.JDBCTemplate;
import com.hoolai.jdbc.PSSetter;
import com.hoolai.jdbc.RSParser;
import com.hoolai.jdbc.SQL;
import com.hoolai.jdbc.TypePSSetter;

public abstract class AbtSQL<T> implements SQL<T> {

    protected final String sql;
    protected final boolean isPureCond;
    protected final JDBCTemplate jdbcTemplate;
    
    protected final TypePSSetter<T> setter;
    protected final RSParser<T> parser;
    
    protected final int batchLimit;

    public AbtSQL(String sql, JDBCTemplate jdbcTemplate, int condCout, int batchLimit, TypePSSetter<T> setter, RSParser<T> parser) {
        this.sql = sql;
        this.jdbcTemplate = jdbcTemplate;
        this.isPureCond = (condCout == 1);//是否where子句中只有一个参数 非单一参数不支持byOneCond方法
        this.batchLimit = batchLimit;
        this.setter = setter;
        this.parser = parser;
    }
    
    public TypePSSetter<T> getSetter() {
		return setter;
	}

	public RSParser<T> getParser() {
		return parser;
	}
	
	public String getSql() {
		return sql;
	}
	
    //fetch
    public T fetchOne(PSSetter setter) {
        return jdbcTemplate.fetchOne(sql, setter, parser);
    }
    public List<T> fetchMany(PSSetter setter) {
        return (List<T>) jdbcTemplate.fetchMany(sql, setter, parser);
    }
    public List<T> fetchManyByIndex(Object idx) {
        return (List<T>) jdbcTemplate.fetchManyByOneCond(sql, idx, parser);
    }

    public T fetchOneByKey(Object key) {
        checkPureCond();
        return jdbcTemplate.fetchOneByOneCond(sql, key, parser);
    }
    
    protected void checkPureCond() {
        if(!isPureCond) {
            throw new IllegalArgumentException("None pure condition for [" + sql + "] to use byKey methods");
        }
    }
    
	@Override
    public long insertAndGenKey(T value) {
        return jdbcTemplate.fetchIncrement(sql, setter, value);
    }

    @Override
    public String toString() {
        return sql;
    }
    
}