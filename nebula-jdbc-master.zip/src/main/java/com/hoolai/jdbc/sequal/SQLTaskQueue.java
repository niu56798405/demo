package com.hoolai.jdbc.sequal;

import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicBoolean;

public class SQLTaskQueue {
    
    private ExecutorService executor;
    private Map<SQLTask, Boolean> map;
    private Queue<SQLTask> queue;
    private AtomicBoolean isRunning;
    private boolean checkoutEnable;
    
    public SQLTaskQueue(ExecutorService exec) {
        this.executor = exec;
        this.map = new ConcurrentHashMap<>();
        this.queue = new ConcurrentLinkedQueue<>();
        this.isRunning = new AtomicBoolean(false);
        this.checkoutEnable = true;
    }
    
    private SQLTask poll() {
        SQLTask task = this.queue.poll();
        if(task != null) this.map.remove(task);
        return task;
    }
    
    private void offer(SQLTask task) {
        if(this.map.putIfAbsent(task, Boolean.TRUE) == null) {
            queue.offer(task);
        }
    }
    
    void checkin(SQLTask task) {
        offer(task);
        
        if(this.isRunning.compareAndSet(false, true)){
           this.execNext();
        }
    }

    private void execNext() {
        SQLTask next = this.queue.peek();
        if(next != null) {
            exec0(next);
        } else {
            this.isRunning.set(false);
            
            //double check
            next = this.queue.peek();
            if(next != null && this.isRunning.compareAndSet(false, true)) {
                exec0(next);
            }
        }
    }

    private void exec0(SQLTask next) {
        if(executor.isShutdown()) {
            executeByLoops();
        } else {
            SQLTask task = poll();
            try {
                executor.execute(task);
            } catch (RejectedExecutionException e) {
                task.run();
            }
        }
    }

    private void executeByLoops() {
        checkoutEnable = false;//不由checkout来处理poll和execNext
        SQLTask next;
        while((next = poll()) != null) {
            next.run();
        }
        checkoutEnable = true;
        execNext();
    }
    
    void checkout(SQLTask task) {
        if (checkoutEnable) {
            this.execNext();
        }
    }
    
    public int size() {
        return map.size();
    }
    
}
