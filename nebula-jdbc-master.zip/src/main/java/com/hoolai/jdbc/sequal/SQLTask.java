package com.hoolai.jdbc.sequal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class SQLTask implements Runnable {

    static final Logger logger = LoggerFactory.getLogger(SQLTask.class);
    
    final SQLTaskQueue queue;
    
    final SQLRunnable runnable;
    
    public SQLTask(SQLTaskQueue queue, SQLRunnable runnable) {
        this.queue = queue;
        this.runnable = runnable;
    }
    
    public void checkin() {
        queue.checkin(this);
    }
    
    public final void run() {
        try {
            runnable.run();
        } finally {
            queue.checkout(this);
        }
    }

    @Override
    public int hashCode() {
        return ((runnable == null) ? 0 : runnable.hashCode());
    }

    @Override
    public boolean equals(Object obj) {
        SQLTask other = (SQLTask) obj;
        if (runnable == null) {
            if (other.runnable != null)
                return false;
        } else if (!runnable.equals(other.runnable))
            return false;
        return true;
    }
    
}
