package com.hoolai.jdbc.compiler;

import com.hoolai.jdbc.Configuration;
import com.hoolai.jdbc.JDBCTemplate;
import com.hoolai.jdbc.RSParser;
import com.hoolai.jdbc.TypePSSetter;
import com.hoolai.jdbc.sequal.AbtSQL;
import com.hoolai.jdbc.sequal.AsyncSQL;
import com.hoolai.jdbc.sequal.SQLTaskQueue;
import com.hoolai.jdbc.sequal.SyncSQL;

public class SQLFactory<T> {
	
	private final int asyncModel;
	private final JDBCTemplate jdbcTemplate;
	private final SQLTaskQueue queue;
	
	public SQLFactory(int asyncModel, JDBCTemplate jdbcTemplate) {
		this.asyncModel = asyncModel;
		this.jdbcTemplate = jdbcTemplate;
		this.queue = new SQLTaskQueue(Configuration.getExecutor());
	}

	public AbtSQL<T> newSQL(String sql, int condCout, int batchLimit, TypePSSetter<T> setter, RSParser<T> parser) {
		if(asyncModel == 1 || (asyncModel == -1 && Configuration.isAsyncModule())) {
			return new AsyncSQL<T>(queue, sql, jdbcTemplate, condCout, batchLimit, setter, parser);
		}
		return new SyncSQL<T>(sql, jdbcTemplate, condCout, batchLimit, setter, parser);
	}
	
}
