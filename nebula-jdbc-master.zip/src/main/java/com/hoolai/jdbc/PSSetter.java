package com.hoolai.jdbc;

import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * PreparedStatement setter
 * @author luzj
 */
public interface PSSetter {
	
	void set(PreparedStatement pstmt) throws SQLException;
	
	PSSetter NONE = pstmt->{};
}
