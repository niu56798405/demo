package com.hoolai.jdbc.codec;

public interface FieldCodec<F, C> {

    C encode(F fieldValue);
    F decode(C columnValue);
    
}
